﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZH_OYBTVS
{
    public partial class UserControl2 : UserControl
    {
        Models. SeCocktailsContext contect = new Models.SeCocktailsContext();
        public UserControl2()
        {
            InitializeComponent();
        }
        

        private void buttonSave_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                MessageBox.Show("Ügyes vagy");
            }
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckSzám(textBox1.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox1, "Nem jó szám");
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckSzöveg(textBox2.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox1, "Nem jó szöveg");
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckSzöveg(textBox2.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox1, "Nem jó szöveg");
            }
        }

        private void textBox4_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckSzám(textBox1.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox1, "Nem jó szám");
            }
        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckSzöveg(textBox2.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox1, "Nem jó szöveg");
            }
        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox1, "");
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox2, "");
        }

        private void textBox3_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox3, "");
        }

        private void textBox4_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox4, "");
        }

        private void textBox5_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox5, "");
        }
        private bool CheckSzám(string recipe)
        {
            Regex r = new Regex("^[0-999]$");
            return r.IsMatch(recipe);
        }
        private bool CheckSzöveg(string material)
        {
            
            return !string.IsNullOrEmpty(material);
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Ha erre a gombra nyomtál, meghívlak a sörre");
        }
    }
}
