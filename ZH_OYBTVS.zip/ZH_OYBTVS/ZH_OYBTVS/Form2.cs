﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZH_OYBTVS
{
    public partial class Form2 : Form
    {
        Models.SeCocktailsContext contect = new Models.SeCocktailsContext();
        public Form2()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (this.ValidateChildren())
            {
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
        }

        private void textBox1_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckRecipe(textBox1.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox1, "háromjegyű számot keresünk");
            }
        }

        private void textBox2_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckMaterial(textBox2.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox1, "Nem lehet üres");
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            if (!CheckRecipe(textBox3.Text))
            {
                e.Cancel = true;
                errorProvider1.SetError(textBox3, "");
            }
        }

        private void textBox4_Validating(object sender, CancelEventArgs e)
        {

        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {

        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox1, "");
        }

        private void textBox2_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox2, "");
        }

        private void textBox3_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox3, "");
        }

        private void textBox4_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox4, "");
        }

        private void textBox5_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(textBox5, "");
        }
        private bool CheckRecipe(string recipe)
        {
            Regex r = new Regex("^[0-999]{3}$");
            return r.IsMatch(recipe);
        }
        private bool CheckMaterial(string material)
        {

            return !string.IsNullOrEmpty(material);
        }
    }
}
