﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ZH3_kidolgozas.Models
{
    public class Szabaly
    {
        public int RecipeSk { get; set; }
        public string MaterialName { get; set; }
        public string MaterialType { get; set; }
        public decimal Quantity { get; set; }
        public string UnitName { get; set; }
    }
}
