﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ZH3_kidolgozas
{
    public partial class UserControl1 : UserControl
    {
        Models.SeCocktailsContext context = new Models.SeCocktailsContext();
        public UserControl1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            ItalSzűrés();
        }
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            HozzávalóSzűrés();
        }

        private void UserControl1_Load(object sender, EventArgs e)
        {
            ItalSzűrés();
            HozzávalóSzűrés();
        }
        private void ItalSzűrés()
        {
            var ital = from x in context.Cocktails
                       where x.Name.Contains(textBox1.Text)
                       select x;
            listBox1.DisplayMember = "Name";
            listBox1.DataSource = ital.ToList();
        }

        private void HozzávalóSzűrés()
        {
            var ital = (Models.Cocktail)listBox1.SelectedItem;
            var recept = from x in context.Recipes
                         where x.CocktailFk == ital.CocktailSk
                         select new Models.Szabaly
                         {
                             RecipeSk = x.RecipeSk,
                             MaterialName = x.MaterialFkNavigation.Name,
                             MaterialType = x.MaterialFkNavigation.TypeFkNavigation.Name,
                             Quantity = x.Quantity,
                             UnitName = x.MaterialFkNavigation.UnitFkNavigation.Name

                         };
            szabalyBindingSource.DataSource= recept.ToList();

        }

        
    }
}
