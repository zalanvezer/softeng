﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace S02E11.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class BoatController : ControllerBase
    {
        [HttpGet]
        [Route("hajo/kerdesek")]
        public IActionResult függvény()
        {
            Models.HajosContext context = new Models.HajosContext();
            var lisa = from x in context.Questions select x;
            return Ok(lisa);
                       
        }
        [HttpGet]
        [Route("hajo/kerdesek/{id}")]
        public IActionResult asd(int id)
        {
            Models.HajosContext context = new Models.HajosContext();
            var lisa = from x in context.Questions
                       where x.QuestionId == id 
                       select x;
            var lisa2 = context.Questions.Where (x => x.QuestionId == id); // másik módszer
            return Ok(lisa);
        }
    }
}
